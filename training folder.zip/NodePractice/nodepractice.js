//console.log(__dirname);
//console.log(__filename);
/*
function Hi(){
    console.log('this is Hi');
}

var bye = function() {
    console.log('this is Bye');
}
Hi();
bye();

function del(hi){
    hi();
}

del(Hi);*/
/*
var counter = function(arr){
    return 'There are '+ arr.length + ' elements in this array';
};

var added = function(a,b) {
    return 'The sum of the 2 numbers $(a+b)'; 
};
module.exports.counter = counter;
module.exports.added = added;
*/
/*
var events = require('events');

var emitter = new events.EventEmitter();

emitter.on('some',function(msg){
    console.log(msg);
})

emitter.emit('some','this is for test');*/

/*var fs = require('fs');

var readMe = fs.readFileSync('test.txt','utf8');

console.log(readMe);
fs.writeFileSync('welcome.txt',readMe);*/
/*
var http =  require('http');

var server = http.createServer(function(req,res){
    res.writeHead(200,{'Content-Type':'text/plain'});
    res.end('Hey shambu');
})

server.listen(3000,'127.0.0.1');*/
/*
var fs = require('fs');

var readMe = fs.createReadStream('test.txt','utf8');

readMe.on('data',function (chunk) {
    console.log(chunk);
})*/

/*
var http =  require('http');
var fs = require('fs');
var server = http.createServer(function(req,res){
    res.writeHead(200,{'Content-Type':'text/html'});
    var readMe = fs.createReadStream('test.html','utf8');
    readMe.pipe(res);
})

server.listen(3000,'127.0.0.1');*/
/*
var http =  require('http');
var server = http.createServer(function(req,res){
    res.writeHead(200,{'Content-Type':'text/plain'});
    var myObj = {
        name:'shambu',
        job: 'developer'
    }
    res.end(JSON.stringify(myObj));
})

server.listen(3000,'127.0.0.1');*/
/*
var http =  require('http');
var fs = require('fs');
var server = http.createServer(function(req,res){
    res.writeHead(200,{'Content-Type':'text/html'});
    if(req.url === '/home'){
        var readMe = fs.createReadStream('index.html','utf8').pipe(res);
    }else if(req.url === '/contact'){
        var readMe = fs.createReadStream('test.html','utf8').pipe(res);
    }
    
})

server.listen(3000,'127.0.0.1');*/
/*
var express = require('express');
var app = express();

app.get('/',function(req,res) {
    res.send('this is for test url');
    
});

app.get('/contact/:id',function(req,res) {
    res.send('this is for test url id'+ req.params.id);
    
});

app.listen(3000);*/

var express = require('express');
var bodyParser = require('body-parser');
var app = express();
app.set('view engine','ejs');
var urlencodedParser = bodyParser.urlencoded({ extended: false });
app.use('/assets',express.static('assets'))
app.get('/',function(req,res) {
    res.render('index',{qs:req.query});
});

app.post('/',urlencodedParser ,function(req,res) {
    res.render('success',{data: req.body});
});
/*
app.get('/contact/:id',function(req,res) {
    res.send('this is for test url id'+ req.params.id);
    
});*/

app.get('/contact/:string',function(req,res) {
    res.send('this is for test url id '+ req.params.string);
    
});

app.listen(3000);


