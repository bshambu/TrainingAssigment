var stuff = require('./nodepractice');
console.log(stuff.counter(['shambu','linga','banagar']));
console.log(stuff.added(1,2));