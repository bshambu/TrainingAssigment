/*function Person(name){
    if(name ==="chandu"){
        greet ="Hello Chandu";
    }else{
        greet ="bye";
    }
    console.log(greet);
}
Person('shambu');
Person('chandu');*/
/*
let names = new Map([['shambu'],['linga'],['banagar']]);

names.forEach(arrayFunction);
function arrayFunction(value,key,callingMap){
console.log(value + " " + key);
}
*/
/*class Account{
    constructor(id=10,name,balance=1000){
        console.log("Hi "+name+" Your Account Id: "+id +" With Balance Amount "+balance);
    }
}
 
class A1 extends Account{

     savings(){
        console.log('this is test for function savings');
    }
     current(){
        console.log('this is test for function current');
     }
    

}
let b = new A1(11,'shambu');

b.current();*/

/*let mySet = Object.create(null);
mySet.id =1;
mySet.name ="this is for test";
if(mySet.id){
    console.log(mySet.id);
}
console.log(mySet.name);*/
/*
function *createGenerator(){
    yield 1;
    console.log("its start");
    yield 2;
    console.log("its end");
    console.log("its end 24");
    yield 3;
    console.log("its end 2");
}
let myGen = createGenerator();

console.log(myGen.next());
console.log(myGen.next());
console.log(myGen.next());*/
/*
let s = Symbol("test symbol");
console.log(typeof s);
console.log(s.toString());
*/
function myDisplayer(some) {
    console.log(some);
  }

let myPromise = new Promise(function(myResolve, myReject) {
    let x = 0;
  
  // some code (try to change x to 5)
  
    if (x == 0) {
      myResolve("OK");
    } else {
      myReject("Error");
    }
  });
  
  myPromise.then(
    function(value) {myDisplayer(value);},
    function(error) {myDisplayer(error);}
  );