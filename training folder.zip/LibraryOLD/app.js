const express = require('express');
const mysql = require('mysql');
const app = express();
const port = 3000;

app.get('/', (req, res) => res.send('this is for test!'));
app.listen(port, () => console.log(`Example app listening on port port!`));

const con  = mysql.createConnection({
    connectionLimit : 10,
    host            : 'localhost',
    user            : 'root',
    password        : '',
    database        : 'restdb'
});

con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });