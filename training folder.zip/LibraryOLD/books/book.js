const mysql = require('mysql');

const con  = mysql.createConnection({
    connectionLimit : 10,
    host            : 'localhost',
    user            : 'root',
    password        : '',
    database        : 'restdb'
});

con.query(`CREATE TABLE IF NOT EXISTS contacts(id NUMBER, name VARCHAR2(50), email VARCHAR2(100) )`
  ,
  function(err) {
  if(err){
      console.log("Error!");
  }
  }
);