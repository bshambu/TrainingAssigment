const express = require('express');
const mysql = require('mysql');
const bodyparser = require('body-parser');
const app = express();
app.use(bodyparser.json());
const port = 3000;


const con  = mysql.createConnection({
    connectionLimit : 10,
    host            : 'localhost',
    user            : 'root',
    password        : '',
    database        : 'restdb'
});

con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

app.get('/', (req, res) => {
    con.query("select * from employees",(err,res)=>{
      console.log(res);
    });
});
app.get('/book/:id', (req, res) => {
  let id = req.params.id;
  con.query("select * from employees where id=?",[id],(err,res)=>{
    if(res){
        console.log(res);
    }else{
        console.log('not valid id');
    }
  });

});

app.delete('/bookDelete/:id', (req, res) => {
  let id = req.params.id;
  con.query("delete from employees where id=?",[id],(err,res)=>{
    if(res){
        console.log("deleted");
    }else{
        console.log('not valid id');
    }
  });
  
});

app.post('/book', (req, res) => {
  let books = req.body;
  con.query("INSERT INTO employees (email,pwd) values('bshambu@gmail.com','12345')",(err, res) => {
    if(err) throw err;
  });

});
app.listen(port, () => console.log(`Example app listening on port port!`));
