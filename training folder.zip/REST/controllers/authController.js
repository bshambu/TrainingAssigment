const User = require('../models/User');
const jwt = require('jsonwebtoken');
const mysql = require('mysql');
const con  = mysql.createConnection({
    connectionLimit : 10,
    host            : 'localhost',
    user            : 'root',
    password        : '',
    database        : 'restdb'
})

module.exports.signup_get = (req,res)=>{
    res.render('signup');
}
module.exports.login_get = (req,res)=>{
    res.render('login');
}
module.exports.signup_post = (req,res)=>{
    const { email, pwd } = req.body;
    con.query('INSERT INTO employees SET ?', [email,pwd], (err, res) => {
        if(err) throw err;
      });
}
module.exports.login_post = (req,res)=>{
    const { email, pwd } = req.body;
    con.query(
        'select * employees Where email = ?',
        ['bshambu@gmail.com'],
        (err, result) => {
          if (err) throw err;
          }
      );
}