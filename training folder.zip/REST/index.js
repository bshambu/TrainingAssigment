const express = require('express');
const http = require('http') 
const mysql = require("mysql");
const app = express();
const router = express.Router();
const authRoute = require('./routes/authRoute')
app.set('view engine','ejs');
app.use(express.json());
app.listen(8080);
//const swaggerJsDoc = require("swagger-jsdoc");
const swaggerUi = require('swagger-ui-express'); 

const pool  = mysql.createConnection({
    connectionLimit : 10,
    host            : 'localhost',
    user            : 'root',
    password        : '',
    database        : 'restdb'
})

app.get('/',(req,res)=>console.log('this is get'));

pool.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });
 
app.use(authRoute);

