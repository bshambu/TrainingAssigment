var bodyParser = require('body-parser')
var data = [{name:'shambu',email:'bshambu@gmail.com'},{name:'test',email:'test@gmail.com'}]
module.exports = function(app){

    app.get('/todo', function(req,res){
        res.render('index');
    });
    app.post('/todo', function(req,res){
        data.push(req.body);
        console.log(data);

    });
    app.delete('/todo', function(req,res){

    });
};